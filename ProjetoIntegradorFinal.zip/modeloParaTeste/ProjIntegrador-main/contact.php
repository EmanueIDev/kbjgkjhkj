<?php
include 'backend/autenticado.php';
?>
<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title> Água | Contate-nos </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

   <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/hamburgers.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/style.css">

<style>
        .logout-btn {
    background: linear-gradient(135deg, #09cc7f, #1ed2ff);
    color: white;
    padding: 10px 20px;
    font-size: 0.95rem;
    font-weight: bold;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s ease;
    font-family: Verdana, Geneva, Tahoma, sans-serif;

    /* sombra */
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
}

.logout-btn:hover {
    background: linear-gradient(135deg, rgb(179, 8, 8), rgb(228, 174, 74));
    transform: translateY(-3px);
    box-shadow: 0 6px 14px rgba(0,0,0,0.20);
}

.logout-btn:active {
    transform: translateY(0px);
    box-shadow: 0 2px 6px rgba(0,0,0,0.15);
}

    </style>
    

</head>
    <!--? Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="logoGOTA.webp" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader Start -->
    <header>
        <!-- Header Start -->
        <div class="header-area">
            <div class="main-header ">
                <div class="header-top d-none d-lg-block">
                    <div class="container-fluid">
                        <div class="col-xl-12">
                            <div class="row d-flex justify-content-between align-items-center">
                                <div class="header-info-left d-flex">
                                    <ul>     
                                        <li>Telefone: (88) 3303-1200</li>
                                        <li>Email: recepcao.aracati@ifce.edu.br</li>
                                    </ul>
                                    <div class="header-social">    
                                        <ul>
                                            
                                            <li><a  href="https://www.facebook.com/IfceAracati/?locale=pt_BR"><i class="fab fa-facebook-f"></i></a></li>
                                            
                                            <li> <a href="https://ifce.edu.br/aracati"><i class="fab fa-google-plus-g"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="header-info-right d-flex align-items-center">
                                    <div class="select-this">
                                        <form action="#">
                                            <div class="select-itms">
                                                <select name="select" id="select1">
                                                    <option value="">Português (BR)</option>
                                                    <option value="">English</option>
                                                    <option value="">Deutsch</option>
                                                    <option value="">Français</option>
                                                </select>
                                            </div>
                                        </form>
                                    </div>
                                    <ul class="contact-now">     
                                        <li><a href="index.html"> Faça parte do nosso projeto! </a></li>
                                    </ul>

                                    <button class="logout-btn" onclick="window.location.href='backend/logout.php'">Logout</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-bottom  header-sticky">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <!-- Logo -->
                            <div class="col-xl-2 col-lg-2">
                                <div class="logo">
                                    <h1 style="color: #1ed2ff"> Água e Vida </h1>
                                </div>
                            </div>
                            <div class="col-xl-10 col-lg-10">
                                <div class="menu-wrapper  d-flex align-items-center justify-content-end">
                                    <!-- Main-menu -->
                                    <div class="main-menu d-none d-lg-block">
                                        <nav>
                                            <ul id="navigation">                                                                                          
                                                <li><a href="index.html">Início</a></li>
                                                <li><a href="about.html">Sobre nós</a></li>
                                                <li><a href="program.html">Causas recentes</a></li>
                                                <li><a href="events.html">Eventos sociais </a></li>
                                                <li><a href="blog.php">Blog</a>
                                                    <ul class="submenu">
                                                        <li><a href="blog.php">Blog</a></li>
                                                        <li><a href="quiz.php">Quiz</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="contact.php">Contate-nos.</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <!-- Header-btn -->
                                    <div class="header-right-btn d-none d-lg-block ml-20">
                                        <a href="contact.php" class="btn header-btn">Doe para a nossa causa</a>
                                    </div>
                                </div>
                            </div> 
                            <!-- Mobile Menu -->
                            <div class="col-12">
                                <div class="mobile_menu d-block d-lg-none"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header End -->
    </header>
    <main>
        <!--? Hero Start -->
        <div class="slider-area2">
            <div class="slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap hero-cap2 pt-20 text-center">
                                <h2>Contate-nos.</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  <section class="contact-section">
    <div class="container">
        <div class="d-none d-sm-block mb-5 pb-4 text-center">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15908.627609921366!2d-37.77921178807132!3d-4.565802886846401!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x7b9b1e756001ebb%3A0xf679966fd97abab9!2sAracati%2C%20CE%2C%2062800-000!5e0!3m2!1spt-BR!2sbr!4v1760029995620!5m2!1spt-BR!2sbr" 
                width="1200" 
                height="600" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>
</section>


<div class="row">
    <div class="col-12">
        <h2 class="contact-title text-center">Deixe sua mensagem ou feedback!</h2>
    </div>
    
    <div class="col-lg-8 mx-auto"> <!-- Adicionamos 'mx-auto' aqui -->
        <form class="form-contact contact_form" action="contact_process.php" method="post" id="contactForm" novalidate="novalidate">
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <textarea class="form-control w-100" name="message" id="message" cols="30" rows="9" placeholder="Digite sua mensagem."></textarea>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <input class="form-control valid" name="name" id="name" type="text" placeholder="Digite seu nome">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <input class="form-control valid" name="email" id="email" type="email" placeholder="Digite seu e-mail">
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <input class="form-control" name="subject" id="subject" type="text" placeholder="Adicionais">
                    </div>
                </div>
            </div>
            <div class="form-group mt-3 text-center">
                <button type="submit" class="button button-contactForm boxed-btn">Enviar</button>
            </div>
        </form>
    </div>
</div>

                            </div>
                        </form>
                    </div>
                    <div class="col-lg-3 offset-lg-1">
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-home"></i></span>
                            <div class="media-body">
                                <h3>Aracati, Ceará.</h3>
                                <p>Conj. Hab. Dr. Abelardo Filho, 62800-000</p>
                            </div>
                        </div>
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-tablet"></i></span>
                            <div class="media-body">
                                <h3>(88) 3303-1200</h3>
                                <p>Telefone (Recepção)</p>
                            </div>
                        </div>
                        <div class="media contact-info">
                            <span class="contact-info__icon"><i class="ti-email"></i></span>
                            <div class="media-body">
                                <h3>recepcao.aracati@ifce.edu.br</h3>
                                <p>Envie suas dúvidas.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact Area End -->
    </main>
    <footer>
        <div class="footer-wrapper section-bg2" data-background="assets/img/gallery/footer_bg.png">
            <!-- Footer Top-->
            <div class="footer-area footer-padding">
                <div class="container">
                    <div class="row d-flex justify-content-between">
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="single-footer-caption mb-50">
                            <div class="single-footer-caption mb-30">
                                <div class="footer-tittle">
                                    <div class="footer-logo mb-20">
                                        <a href="index.html"><img src="logoGOTA3.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-5">
                            <div class="single-footer-caption mb-50">
                                <div class="footer-tittle">
                                    <h4>Informações para contato.</h4>
                                  
                                    <ul>
                                        <li>
                                            <p>Endereço:  Conj. Hab. Dr. Abelardo Filho, Aracati - CE, 62800-000. Instituto Federal de Educação, Ciência e Tecnologia do Ceará - Campus Aracati</p>
                                        </li>
                                        <li><a href="#">Telefone : (88) 3303-1200</a></li>
                                        <li><a href="#">Email : recepcao.aracati@ifce.edu.br</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-5">
                            <div class="single-footer-caption mb-50">
                                <div class="footer-tittle">
                                    <h4>Notícias Recentes.</h4>
                                    <ul>
                                        <li><a href="https://www.gov.br/mdr/pt-br/noticias/agua-ganha-protagonismo-na-agenda-climatica-do-midr-rumo-a-cop30"> Água ganha protagonismo na agenda climática do MIDR rumo à COP30.</a></li>
                                        <li><a href="https://www.destaquenoticias.com.br/obras-de-abastecimento-de-agua-estao-em-fase-final/">Obras de abastecimento de água estão em fase final.</a></li>
                                        <li><a href="https://www.ceara.gov.br/2025/10/09/governo-do-ceara-amplia-abastecimento-de-agua-para-beneficiar-mais-de-1-700-familias-em-zonas-rurais-de-22-municipios/">Governo do Ceará amplia abastecimento de água para beneficiar mais de 1.700 famílias em zonas rurais de 22 municípios.</a></li>
                                        <li><a href="https://g1.globo.com/jornal-nacional/noticia/2025/03/21/pesquisa-revela-que-reservas-de-agua-doce-no-brasil-estao-secando-em-ritmo-mais-acelerado.ghtml/">Pesquisa revela que reservas de água doce no Brasil estão secando em ritmo mais acelerado.</a></li>
                                        <li><a href="https://g1.globo.com/economia/noticia/2024/06/05/desperdicio-de-agua-diminui-no-brasil-pela-1a-vez-em-6-anos-mas-ainda-esta-longe-da-meta.ghtml">Desperdício de água diminui no Brasil pela 1ª vez em 6 anos, mas ainda está longe da meta</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-5">
                            <div class="single-footer-caption mb-50">
                                <div class="footer-tittle">
                                    <h4>Dúvidas.</h4>
                                    <div class="footer-pera footer-pera2">
                                    <p>Envie suas dúvidas.</p>
                                </div>
                                <!-- Form -->
                                <div class="footer-form" >
                                    <div id="mc_embed_signup">
                                        <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
                                        method="get" class="subscribe_form relative mail_part">
                                            <input type="email" name="email" id="newsletter-form-email" placeholder="Digite aqui."
                                            class="placeholder hide-on-focus" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ' Email Address '">
                                            <div class="form-icon">
                                                <button type="submit" name="submit" id="newsletter-submit"
                                                class="email_icon newsletter-submit button-contactForm"><img src="assets/img/gallery/form.png" alt=""></button>
                                            </div>
                                            <div class="mt-10 info"></div>
                                        </form>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- footer-bottom -->
            <div class="footer-bottom-area">
                <div class="container">
                    <div class="footer-border">
                        <div class="row d-flex justify-content-between align-items-center">
                            <div class="col-xl-10 col-lg-9 ">
                                <div class="footer-copy-right">
                                    <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                                </div>
                            </div>
                            <div class="col-xl-2 col-lg-3">
                                <div class="footer-social f-right">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a  href="https://www.facebook.com/sai4ull"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fas fa-globe"></i></a>
                                    <a href="#"><i class="fab fa-behance"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Scroll Up -->
    <div id="back-top" >
        <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
    </div>
      <!-- JS here -->

      <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
      <!-- Jquery, Popper, Bootstrap -->
      <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
      <script src="./assets/js/popper.min.js"></script>
      <script src="./assets/js/bootstrap.min.js"></script>
      <!-- Jquery Mobile Menu -->
      <script src="./assets/js/jquery.slicknav.min.js"></script>

      <!-- Jquery Slick , Owl-Carousel Plugins -->
      <script src="./assets/js/owl.carousel.min.js"></script>
      <script src="./assets/js/slick.min.js"></script>
      <!-- One Page, Animated-HeadLin -->
      <script src="./assets/js/wow.min.js"></script>
      <script src="./assets/js/animated.headline.js"></script>
      <script src="./assets/js/jquery.magnific-popup.js"></script>

      <!-- Date Picker -->
      <script src="./assets/js/gijgo.min.js"></script>
      <!-- Nice-select, sticky -->
      <script src="./assets/js/jquery.nice-select.min.js"></script>
      <script src="./assets/js/jquery.sticky.js"></script>
      
      <!-- counter , waypoint,Hover Direction -->
      <script src="./assets/js/jquery.counterup.min.js"></script>
      <script src="./assets/js/waypoints.min.js"></script>
      <script src="./assets/js/jquery.countdown.min.js"></script>
      <script src="./assets/js/hover-direction-snake.min.js"></script>

      <!-- contact js -->
      <script src="./assets/js/contact.js"></script>
      <script src="./assets/js/jquery.form.js"></script>
      <script src="./assets/js/jquery.validate.min.js"></script>
      <script src="./assets/js/mail-script.js"></script>
      <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
      
      <!-- Jquery Plugins, main Jquery -->	
      <script src="./assets/js/plugins.js"></script>
      <script src="./assets/js/main.js"></script>

      <script>
function logout() {
    localStorage.removeItem("logado");
    window.location.href = "login.html";
}
</script>
     
    </body>
</html>